<div class="card-text card-file-uploaded"><a href="../files/{{$file->name}}" target="_blank"><i
    class="far fa-file"></i>{{$file->name}}</a>
</div>